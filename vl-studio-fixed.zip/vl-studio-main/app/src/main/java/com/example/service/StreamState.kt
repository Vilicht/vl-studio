package com.example.service

import android.graphics.Bitmap

enum class StreamingStatus {
    OFFLINE,
    CONNECTING,
    LIVE,
    PAUSED,
    RECONNECTING,
    ERROR,
    PREVIEW
}

data class DiagnosticStats(
    val status: StreamingStatus = StreamingStatus.OFFLINE,
    val virtualDisplayActive: Boolean = false,
    /** FPS render nyata dari compositor/encoder (FpsListener RootEncoder). */
    val fps: Int = 0,
    /** Bitrate keluaran nyata (kbps), diukur dari byte yang terkirim, bukan nilai konfigurasi. */
    val bitrateKbps: Int = 0,
    /** Frame video yang dibuang klien RTMP karena antrean penuh/jaringan lambat (nilai nyata). */
    val droppedFrames: Long = 0,
    /** Frame video yang sudah terkirim (nilai nyata). */
    val totalFrames: Long = 0,
    val bytesSent: Long = 0,
    val reconnectCount: Int = 0,
    val durationSeconds: Long = 0,
    val thermalStatus: String = "Normal",
    val destinationUrl: String = "",
    val resolution: String = "1280x720 @ 30fps"
)

data class LiveStudioState(
    val status: StreamingStatus = StreamingStatus.OFFLINE,
    val isMicMuted: Boolean = false,
    val isPreviewFrozen: Boolean = false,
    val frozenSnapshot: Bitmap? = null,
    val errorMessage: String? = null,
    /** true saat Studio terbuka: layer game dibekukan di siaran (kamera & overlay tetap hidup). */
    val isEditorMode: Boolean = false,
    /** Rasio lebar/tinggi layar yang di-capture (0 = belum diketahui). */
    val captureAspect: Float = 0f,
    val stats: DiagnosticStats = DiagnosticStats()
)
