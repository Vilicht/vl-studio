package com.example.ui.components

import android.graphics.Bitmap
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitTouchSlopOrCancellation
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.data.model.SourceEntity
import com.example.data.model.SourceType
import com.example.engine.StudioEngine
import com.example.ui.theme.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private enum class Corner { TL, TR, BL, BR }
private sealed interface DragMode {
    data object Move : DragMode
    data class Resize(val corner: Corner) : DragMode
}

private const val MIN_SIZE = 0.04f

/**
 * Editor kanvas. SATU sistem koordinat: semua posisi/ukuran source disimpan sebagai pecahan canvas (0..1)
 * dan digambar/di-hit-test dalam piksel canvas (pecahan x lebar/tinggi). Compositor GL memakai pecahan
 * yang sama, sehingga posisi di editor = posisi di hasil siaran.
 *
 * Saat engine aktif, latar editor adalah hasil komposisi nyata (SurfaceView yang sama dengan isi RTMP):
 * kamera, browser, teks, dan gambar tampil apa adanya. Compose hanya menggambar garis bantu, handle,
 * dan screenshot referensi di atasnya. Saat engine belum jalan, source digambar sebagai placeholder.
 */
@Composable
fun StudioCanvas(
    sources: List<SourceEntity>,
    selectedId: String?,
    isPortrait: Boolean,
    gameSnapshot: Bitmap?,
    isEngineRunning: Boolean,
    isEditorMode: Boolean,
    showSafeArea: Boolean,
    snapEnabled: Boolean,
    isFullscreen: Boolean,
    canUndo: Boolean,
    canRedo: Boolean,
    hasCamera: Boolean,
    onSelect: (String?) -> Unit,
    onBeginEdit: () -> Unit,
    onPreviewTransform: (SourceEntity) -> Unit,
    onCommitTransform: (SourceEntity) -> Unit,
    onSurfaceReady: (Surface, Int, Int) -> Unit,
    onSurfaceGone: (Surface) -> Unit,
    onToggleFullscreen: () -> Unit,
    onToggleSafeArea: () -> Unit,
    onToggleSnap: () -> Unit,
    onImportReference: () -> Unit,
    onClearSnapshot: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onSwitchCamera: () -> Unit,
    modifier: Modifier = Modifier
) {
    val aspect = if (isPortrait) 9f / 16f else 16f / 9f
    val density = LocalDensity.current

    // Versi "hidup" source yang sedang di-drag; dipakai agar gerakan mulus tanpa menunggu database
    var live by remember { mutableStateOf<SourceEntity?>(null) }
    LaunchedEffect(sources) {
        val l = live
        if (l != null && sources.any { it == l }) live = null
    }
    val display = remember(sources, live) { sources.map { if (it.id == live?.id) live!! else it } }

    var guidesX by remember { mutableStateOf<List<Float>>(emptyList()) }
    var guidesY by remember { mutableStateOf<List<Float>>(emptyList()) }
    var dragging by remember { mutableStateOf(false) }

    val latestDisplay by rememberUpdatedState(display)
    val latestSelected by rememberUpdatedState(selectedId)
    val latestSnap by rememberUpdatedState(snapEnabled)
    val latestPreview by rememberUpdatedState(onPreviewTransform)
    val latestCommit by rememberUpdatedState(onCommitTransform)
    val latestSelect by rememberUpdatedState(onSelect)
    val latestBegin by rememberUpdatedState(onBeginEdit)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CharcoalMain)
            .padding(if (isFullscreen) 0.dp else 10.dp)
            .testTag("studio_canvas_container"),
        contentAlignment = Alignment.Center
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .aspectRatio(aspect)
                .fillMaxSize()
                .border(1.dp, CharcoalBorder)
                .clipToBounds()
                .testTag("preview_canvas")
        ) {
            val cw = constraints.maxWidth.toFloat()
            val ch = constraints.maxHeight.toFloat()
            val latestCw by rememberUpdatedState(cw)
            val latestCh by rememberUpdatedState(ch)

            // ---- Latar: hasil komposisi nyata (engine aktif) atau hitam
            Box(Modifier.fillMaxSize().background(Color.Black))
            if (isEngineRunning) {
                val ready by rememberUpdatedState(onSurfaceReady)
                val gone by rememberUpdatedState(onSurfaceGone)
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        SurfaceView(ctx).apply {
                            holder.addCallback(object : SurfaceHolder.Callback {
                                override fun surfaceCreated(h: SurfaceHolder) {}
                                override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {
                                    ready(h.surface, w, hh)
                                }
                                override fun surfaceDestroyed(h: SurfaceHolder) { gone(h.surface) }
                            })
                        }
                    }
                )
            } else {
                // Engine belum jalan: placeholder tiap source, urut z
                display.filter { it.isVisible && !it.isReference }.sortedBy { it.zIndex }.forEach { s ->
                    PlaceholderItem(s, cw, ch, gameSnapshot, density.density)
                }
            }

            // ---- Screenshot referensi (hanya editor, tidak pernah ke RTMP)
            display.filter { it.isVisible && it.isReference && !it.contentUri.isNullOrEmpty() }.forEach { s ->
                Box(
                    Modifier
                        .offset { IntOffset((s.x * cw).roundToInt(), (s.y * ch).roundToInt()) }
                        .size(with(density) { (s.width * cw).toDp() }, with(density) { (s.height * ch).toDp() })
                ) {
                    AsyncImage(
                        model = s.contentUri, contentDescription = "Referensi",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.FillBounds, alpha = s.opacity
                    )
                }
            }

            // ---- Garis bantu, safe area, seleksi + handle
            val sel = display.firstOrNull { it.id == selectedId && it.isVisible }
            Canvas(Modifier.fillMaxSize()) {
                if (showSafeArea) {
                    val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))
                    drawRect(
                        Color.White.copy(alpha = 0.45f),
                        topLeft = Offset(size.width * 0.05f, size.height * 0.05f),
                        size = Size(size.width * 0.9f, size.height * 0.9f),
                        style = Stroke(width = 1.5f, pathEffect = dash)
                    )
                    drawRect(
                        Color.White.copy(alpha = 0.25f),
                        topLeft = Offset(size.width * 0.1f, size.height * 0.1f),
                        size = Size(size.width * 0.8f, size.height * 0.8f),
                        style = Stroke(width = 1f, pathEffect = dash)
                    )
                }
                if (dragging) {
                    // Garis tengah canvas selalu tampil saat drag
                    val faint = Color.White.copy(alpha = 0.18f)
                    drawLine(faint, Offset(size.width / 2, 0f), Offset(size.width / 2, size.height), 1f)
                    drawLine(faint, Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 1f)
                    guidesX.forEach { gx ->
                        drawLine(Color(0xFFF472B6), Offset(gx * size.width, 0f), Offset(gx * size.width, size.height), 2f)
                    }
                    guidesY.forEach { gy ->
                        drawLine(Color(0xFFF472B6), Offset(0f, gy * size.height), Offset(size.width, gy * size.height), 2f)
                    }
                }
                if (sel != null) {
                    val r = Rect(sel.x * size.width, sel.y * size.height, (sel.x + sel.width) * size.width, (sel.y + sel.height) * size.height)
                    drawRect(ChampagneGold, r.topLeft, r.size, style = Stroke(width = 3f))
                    if (!sel.isLocked) {
                        val rad = 7.dp.toPx()
                        listOf(r.topLeft, r.topRight, r.bottomLeft, r.bottomRight).forEach { c ->
                            drawCircle(Color.White, rad + 2f, c)
                            drawCircle(ChampagneGold, rad, c)
                        }
                    }
                }
            }

            // ---- Gestur: tap pilih, drag pindah, handle sudut untuk resize
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        val hitR = 26.dp.toPx()
                        val thr = 8.dp.toPx()
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val W = latestCw
                            val H = latestCh
                            val list = latestDisplay
                            val p = down.position
                            fun rectOf(s: SourceEntity) = Rect(s.x * W, s.y * H, (s.x + s.width) * W, (s.y + s.height) * H)

                            // 1) handle resize pada source terpilih
                            var target: SourceEntity? = null
                            var mode: DragMode = DragMode.Move
                            val cur = list.firstOrNull { it.id == latestSelected && it.isVisible && !it.isLocked }
                            if (cur != null) {
                                val r = rectOf(cur)
                                val hit = listOf(
                                    Corner.TL to r.topLeft, Corner.TR to r.topRight,
                                    Corner.BL to r.bottomLeft, Corner.BR to r.bottomRight
                                ).firstOrNull { (_, c) -> (c - p).getDistance() <= hitR }
                                if (hit != null) { target = cur; mode = DragMode.Resize(hit.first) }
                            }
                            // 2) source paling atas di titik sentuh
                            if (target == null) {
                                target = list.filter { it.isVisible && rectOf(it).contains(p) }
                                    .maxByOrNull { if (it.isReference) -1 else it.zIndex }
                            }
                            if (target == null) {
                                latestSelect(null)
                                return@awaitEachGesture
                            }
                            val start = target
                            latestSelect(start.id)
                            if (start.isLocked) return@awaitEachGesture

                            val slop = awaitTouchSlopOrCancellation(down.id) { change, _ -> change.consume() }
                                ?: return@awaitEachGesture
                            latestBegin()
                            dragging = true
                            val startRect = rectOf(start)
                            val origin = down.position
                            var result = start

                            fun targetsX(): List<Float> = listOf(0f, 0.05f, 0.5f, 0.95f, 1f) +
                                list.filter { it.id != start.id && it.isVisible && !it.isReference }
                                    .flatMap { listOf(it.x, it.x + it.width / 2, it.x + it.width) }
                            fun targetsY(): List<Float> = listOf(0f, 0.05f, 0.5f, 0.95f, 1f) +
                                list.filter { it.id != start.id && it.isVisible && !it.isReference }
                                    .flatMap { listOf(it.y, it.y + it.height / 2, it.y + it.height) }
                            val tx = targetsX()
                            val ty = targetsY()

                            // Snap: cari selisih terkecil antara tepi kandidat dan target; kembalikan (koreksi, garis)
                            fun snap(edges: List<Float>, targets: List<Float>, px: Float): Pair<Float, Float?> {
                                if (!latestSnap) return 0f to null
                                var best = Float.MAX_VALUE
                                var line: Float? = null
                                for (e in edges) for (t in targets) {
                                    val d = t - e
                                    if (abs(d) * px < thr && abs(d) < abs(best)) { best = d; line = t }
                                }
                                return if (line == null) 0f to null else best to line
                            }

                            fun applyDrag(pos: Offset) {
                                val dx = pos.x - origin.x
                                val dy = pos.y - origin.y
                                var gx: Float? = null
                                var gy: Float? = null
                                val updated: SourceEntity = when (val m = mode) {
                                    DragMode.Move -> {
                                        var nx = start.x + dx / W
                                        var ny = start.y + dy / H
                                        val sx = snap(listOf(nx, nx + start.width / 2, nx + start.width), tx, W)
                                        val sy = snap(listOf(ny, ny + start.height / 2, ny + start.height), ty, H)
                                        nx += sx.first; ny += sy.first; gx = sx.second; gy = sy.second
                                        start.copy(
                                            x = nx.coerceIn(0f, max(0f, 1f - start.width)),
                                            y = ny.coerceIn(0f, max(0f, 1f - start.height))
                                        )
                                    }
                                    is DragMode.Resize -> {
                                        // Sudut yang ditarik, dan sudut seberangnya (tetap diam)
                                        val grab = when (m.corner) {
                                            Corner.TL -> startRect.topLeft; Corner.TR -> startRect.topRight
                                            Corner.BL -> startRect.bottomLeft; Corner.BR -> startRect.bottomRight
                                        }
                                        val anchor = when (m.corner) {
                                            Corner.TL -> startRect.bottomRight; Corner.TR -> startRect.bottomLeft
                                            Corner.BL -> startRect.topRight; Corner.BR -> startRect.topLeft
                                        }
                                        var cx = ((grab.x + dx) / W).coerceIn(0f, 1f)
                                        var cy = ((grab.y + dy) / H).coerceIn(0f, 1f)
                                        val sx = snap(listOf(cx), tx, W); val sy = snap(listOf(cy), ty, H)
                                        cx += sx.first; cy += sy.first; gx = sx.second; gy = sy.second
                                        val ax = anchor.x / W
                                        val ay = anchor.y / H
                                        var nw = abs(cx - ax).coerceAtLeast(MIN_SIZE)
                                        var nh = abs(cy - ay).coerceAtLeast(MIN_SIZE)
                                        if (start.aspectLocked) {
                                            // rasio piksel awal dipertahankan
                                            val ratio = (start.width * W) / (start.height * H)
                                            nh = (nw * W / ratio) / H
                                            if (nh < MIN_SIZE) { nh = MIN_SIZE; nw = (nh * H * ratio) / W }
                                        }
                                        val left = if (cx < ax) ax - nw else ax
                                        val top = if (cy < ay) ay - nh else ay
                                        // jangan keluar canvas
                                        val fl = left.coerceIn(0f, 1f - min(nw, 1f))
                                        val ft = top.coerceIn(0f, 1f - min(nh, 1f))
                                        start.copy(x = fl, y = ft, width = min(nw, 1f - fl), height = min(nh, 1f - ft))
                                    }
                                }
                                guidesX = listOfNotNull(gx)
                                guidesY = listOfNotNull(gy)
                                result = updated
                                live = updated
                                latestPreview(updated)
                            }

                            applyDrag(slop.position)
                            drag(slop.id) { change ->
                                change.consume()
                                applyDrag(change.position)
                            }
                            dragging = false
                            guidesX = emptyList(); guidesY = emptyList()
                            latestCommit(result)
                        }
                    }
            )

            // ---- Spanduk mode edit (jujur tentang apa yang terjadi di siaran)
            if (isEngineRunning && isEditorMode) {
                Surface(
                    color = CharcoalPanel.copy(alpha = 0.92f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp)
                ) {
                    Text(
                        "Mode edit: layar game dibekukan di siaran selama Studio terbuka. Kamera & overlay tetap live.",
                        color = TextPrimary, fontSize = 11.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            // ---- Toolbar canvas (target sentuh 40dp)
            Row(
                Modifier.align(Alignment.TopEnd).padding(6.dp)
                    .background(CharcoalPanel.copy(alpha = 0.85f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                ToolbarButton(Icons.Default.Undo, "Undo", canUndo, false, onUndo)
                ToolbarButton(Icons.Default.Redo, "Redo", canRedo, false, onRedo)
                if (hasCamera) ToolbarButton(Icons.Default.Cameraswitch, "Ganti kamera", true, false, onSwitchCamera)
                ToolbarButton(Icons.Default.GridOn, "Snapping", true, snapEnabled, onToggleSnap)
                ToolbarButton(Icons.Default.CropFree, "Safe area", true, showSafeArea, onToggleSafeArea)
                ToolbarButton(Icons.Default.AddPhotoAlternate, "Impor screenshot referensi", true, false, onImportReference)
                if (gameSnapshot != null) ToolbarButton(Icons.Default.HideImage, "Hapus snapshot game", true, false, onClearSnapshot)
                ToolbarButton(
                    if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                    if (isFullscreen) "Keluar fullscreen" else "Fullscreen", true, false, onToggleFullscreen
                )
            }
        }
    }
}

@Composable
private fun ToolbarButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    enabled: Boolean,
    active: Boolean,
    onClick: () -> Unit
) {
    IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(40.dp)) {
        Icon(
            icon, contentDescription = desc,
            tint = when { !enabled -> TextMuted; active -> ChampagneGoldLight; else -> TextPrimary },
            modifier = Modifier.size(20.dp)
        )
    }
}

/** Gambaran sementara source saat engine belum jalan (kamera/browser baru bisa nyata setelah engine aktif). */
@Composable
private fun PlaceholderItem(s: SourceEntity, cw: Float, ch: Float, snapshot: Bitmap?, density: Float) {
    val wPx = s.width * cw
    val hPx = s.height * ch
    Box(
        Modifier
            .offset { IntOffset((s.x * cw).roundToInt(), (s.y * ch).roundToInt()) }
            .size((wPx / density).dp, (hPx / density).dp)
            .background(Color.Transparent),
        contentAlignment = Alignment.Center
    ) {
        when (s.type) {
            SourceType.SCREEN -> {
                if (snapshot != null) Image(
                    snapshot.asImageBitmap(), "Snapshot game",
                    Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds
                ) else Placeholder(Icons.Default.ScreenShare, "LAYAR GAME", "Mulai siaran lalu atur layout dari game")
            }
            SourceType.CAMERA -> Placeholder(Icons.Default.Videocam, "KAMERA", "Tampil nyata setelah engine aktif")
            SourceType.WEB -> Placeholder(Icons.Default.Language, "BROWSER", s.contentUri?.takeLast(40) ?: "")
            SourceType.IMAGE -> if (!s.contentUri.isNullOrEmpty()) AsyncImage(
                s.contentUri, s.name, Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds, alpha = s.opacity
            ) else Placeholder(Icons.Default.Image, "GAMBAR", "")
            SourceType.TEXT -> {
                val text = s.textContent ?: "TEXT"
                val sizePx = StudioEngine.textSizePx(text, wPx, hPx)
                Box(
                    Modifier.fillMaxSize().background(Color(s.textBgColor), RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text, color = Color(s.textColor), fontWeight = FontWeight.Bold,
                        fontSize = (sizePx / density).sp, maxLines = 1, overflow = TextOverflow.Clip, softWrap = false
                    )
                }
            }
        }
    }
}

@Composable
private fun Placeholder(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String) {
    Column(
        Modifier.fillMaxSize().background(CharcoalSurface.copy(alpha = 0.7f)).border(1.dp, CharcoalBorder),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = ChampagneGoldLight, modifier = Modifier.size(24.dp))
        Text(title, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        if (sub.isNotEmpty()) Text(sub, color = TextSecondary, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
