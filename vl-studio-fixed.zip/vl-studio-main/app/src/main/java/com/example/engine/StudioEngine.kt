package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Surface
import android.view.WindowManager
import com.example.audio.GameMicAudioSource
import com.example.data.model.SourceEntity
import com.example.data.model.SourceType
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.gl.render.filters.AndroidViewFilterRender
import com.pedro.encoder.input.gl.render.filters.BaseFilterRender
import com.pedro.encoder.input.gl.render.filters.`object`.BaseObjectFilterRender
import com.pedro.encoder.input.gl.render.filters.`object`.ImageObjectFilterRender
import com.pedro.encoder.input.gl.render.filters.`object`.SurfaceFilterRender
import com.pedro.encoder.input.sources.video.NoVideoSource
import com.pedro.encoder.utils.gl.AspectRatioMode
import com.pedro.library.rtmp.RtmpStream
import com.pedro.library.view.GlStreamInterface
import com.pedro.library.view.TakePhotoCallback
import com.pedro.library.view.preview.MultiPreviewConfig
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Posisi layer relatif terhadap canvas, 0..1 (x,y = pojok kiri atas). */
data class LayerRect(val x: Float, val y: Float, val w: Float, val h: Float)

/** Penghitung nyata dari klien RTMP (bukan angka konfigurasi). */
data class EngineCounters(val sentVideoFrames: Long, val droppedVideoFrames: Long, val bytesSent: Long)

/**
 * Mesin siaran: satu MediaProjection -> satu VirtualDisplay -> layer "game" di compositor GL,
 * ditambah layer kamera, gambar, teks, dan Browser Source (WebView) di atasnya dengan urutan z
 * yang diatur dari editor. Semua layer ini dikomposisikan di GL SEBELUM encoder, jadi yang dilihat
 * penonton RTMP sama dengan yang ada di editor.
 *
 * Alur: startPreview() -> applyScene() (setiap source berubah) -> goLive() -> stopLive() -> release().
 * Semua fungsi publik dipanggil dari Main Thread (service).
 *
 * Mode editor: saat Studio terbuka, capture layar game dijeda (VirtualDisplay.setSurface(null)) sehingga
 * layer game membeku di frame terakhir. Ini mencegah Studio ikut ter-capture (efek cermin tak berujung)
 * dan TIDAK menghentikan encoder, RTMP, kamera, ataupun overlay.
 */
class StudioEngine(
    private val context: Context,
    private val connectChecker: ConnectChecker
) {
    private val tag = "VilichtEngine"
    private val main = Handler(Looper.getMainLooper())

    private var stream: RtmpStream? = null
    private var projection: MediaProjection? = null
    private var gameSurface: Surface? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var vdThread: HandlerThread? = null
    private var previewReader: ImageReader? = null
    private var studioSurface: Surface? = null

    private val webHost = WebOverlayHost(context)
    private val decoder: ExecutorService = Executors.newSingleThreadExecutor()

    private class Layer(val key: String, val sig: String, val filter: BaseFilterRender) {
        var src: SourceEntity? = null
        var camera: CameraLayerSource? = null
        var web: WebOverlayHost.Handle? = null
        @Volatile var dead = false
    }

    private data class Desired(val key: String, val sig: String, val src: SourceEntity)

    private val layers = mutableListOf<Layer>()
    private var desired: List<Desired> = emptyList()

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.w(tag, "MediaProjection stopped")
            main.post { onProjectionStopped?.invoke() }
        }
    }

    var onProjectionStopped: (() -> Unit)? = null
    /** Error fatal (encoder/capture gagal). Service mengubah status menjadi ERROR. */
    var onError: ((String) -> Unit)? = null
    /** Pemberitahuan non-fatal (kamera terputus, izin overlay kurang, dsb). Siaran tetap jalan. */
    var onNotice: ((String) -> Unit)? = null
    /** Rasio aspek (lebar/tinggi) layar yang sedang di-capture. */
    var onCaptureAspect: ((Float) -> Unit)? = null

    @Volatile var currentFps: Int = 0
        private set

    var canvasW = 1280
        private set
    var canvasH = 720
        private set
    private var fps = 30
    private var capW = 0
    private var capH = 0
    private var gameCaptureActive = true

    val isPreviewing: Boolean get() = stream?.isOnPreview == true
    val isLive: Boolean get() = stream?.isStreaming == true

    /** width/height = ukuran landscape (mis. 1280x720); portrait dihitung dari flag. */
    fun startPreview(
        mp: MediaProjection, portrait: Boolean, width: Int, height: Int, fps: Int, bitrateBps: Int
    ): Boolean {
        release()
        projection = mp
        this.fps = fps
        val long = maxOf(width, height)
        val short = minOf(width, height)
        canvasW = if (portrait) short else long
        canvasH = if (portrait) long else short

        // Android 14+: callback harus terdaftar sebelum createVirtualDisplay
        mp.registerCallback(projectionCallback, main)

        val audio = GameMicAudioSource(mp, context)
        val s = RtmpStream(context, connectChecker, NoVideoSource(), audio)
        stream = s
        s.setFpsListener { f -> currentFps = f }

        // Konvensi RootEncoder: portrait = ukuran landscape + rotation 90
        val rotation = if (portrait) 90 else 0
        if (!s.prepareVideo(long, short, bitrateBps, fps, 2, rotation)) {
            Log.e(tag, "prepareVideo gagal")
            return false
        }
        val gl = s.getGlInterface()
        // Tidak ada frame dari source utama, jadi render dipaksa berjalan sesuai fps
        gl.setForceRender(true, fps)

        // Preview utama "kosong" yang terus dikuras. Ia menjaga thread GL tetap hidup selama engine
        // aktif; preview Studio ditambahkan/dilepas sebagai surface tambahan (multi-preview) tanpa
        // pernah menyentuh encoder atau RTMP.
        val pw = maxOf(canvasW / 8, 16)
        val ph = maxOf(canvasH / 8, 16)
        val reader = ImageReader.newInstance(pw, ph, PixelFormat.RGBA_8888, 2)
        reader.setOnImageAvailableListener({ r ->
            try { r.acquireLatestImage()?.close() } catch (_: Exception) {}
        }, main)
        previewReader = reader
        s.startPreview(reader.surface, pw, ph)

        // Sebelum editor mengirim scene: satu layer game memenuhi canvas
        applyScene(emptyList(), defaultGame = true)
        return true
    }

    // ---------------------------------------------------------------- scene / layer

    /**
     * Sinkronkan layer GL dengan daftar source scene. Perubahan posisi/ukuran/opacity diterapkan
     * seketika; perubahan struktur (tambah/hapus/urutan/konten) diterapkan dengan debounce singkat
     * karena layer di atasnya harus dibuat ulang.
     */
    fun applyScene(sources: List<SourceEntity>, defaultGame: Boolean = false) {
        if (stream == null) return
        val d = if (defaultGame) {
            listOf(Desired("SCREEN", "S", SourceEntity(sceneId = "", name = "game", type = SourceType.SCREEN)))
        } else computeDesired(sources)
        desired = d

        val sameStructure = d.size == layers.size &&
            d.indices.all { d[it].key == layers[it].key && d[it].sig == layers[it].sig }
        main.removeCallbacks(reconcileRunnable)
        if (sameStructure) {
            d.forEachIndexed { i, x -> layers[i].src = x.src; place(layers[i]) }
        } else {
            // Layer yang tidak berubah tetap digerakkan seketika selagi menunggu debounce
            for (l in layers) desired.firstOrNull { it.key == l.key && it.sig == l.sig }?.let { l.src = it.src; place(l) }
            if (layers.isEmpty()) reconcile() else main.postDelayed(reconcileRunnable, 120)
        }
    }

    private val reconcileRunnable = Runnable { reconcile() }

    private fun computeDesired(sources: List<SourceEntity>): List<Desired> {
        var screen = false
        var cam = false
        val out = mutableListOf<Desired>()
        for (s in sources.filter { it.isVisible }.sortedBy { it.zIndex }) {
            when (s.type) {
                SourceType.SCREEN -> if (!screen) { screen = true; out += Desired("SCREEN", "S", s) }
                SourceType.CAMERA -> if (!cam) { cam = true; out += Desired("CAMERA", "C:${s.cameraId}", s) }
                SourceType.IMAGE ->
                    // Screenshot referensi hanya untuk editor: TIDAK PERNAH ikut ke output RTMP
                    if (!s.isReference && !s.contentUri.isNullOrEmpty()) out += Desired(s.id, "I:${s.contentUri}", s)
                SourceType.TEXT ->
                    out += Desired(
                        s.id,
                        "T:${s.textContent}|${s.textColor}|${s.textBgColor}|${(s.width * 100).roundToInt()}|${(s.height * 100).roundToInt()}",
                        s
                    )
                SourceType.WEB ->
                    if (!s.contentUri.isNullOrBlank()) out += Desired(
                        s.id,
                        "W:${s.webMode}|${s.contentUri}|${cssDim(s.width, canvasW)}x${cssDim(s.height, canvasH)}",
                        s
                    )
            }
        }
        return out
    }

    private fun reconcile() {
        val s = stream ?: return
        val gl = s.getGlInterface()
        var i = 0
        while (i < layers.size && i < desired.size &&
            layers[i].key == desired[i].key && layers[i].sig == desired[i].sig
        ) {
            layers[i].src = desired[i].src
            place(layers[i])
            i++
        }
        // Buang dari atas ke bawah, lalu bangun ulang sisanya sesuai urutan z
        for (j in layers.size - 1 downTo i) removeLayer(layers[j], gl)
        for (j in i until desired.size) addLayer(desired[j], gl)
    }

    private fun addLayer(d: Desired, gl: GlStreamInterface) {
        val src = d.src
        val holder = arrayOfNulls<Layer>(1)
        val layer: Layer = when (src.type) {
            SourceType.SCREEN -> {
                val f = SurfaceFilterRender(SurfaceFilterRender.SurfaceReadyCallback { st ->
                    if (holder[0]?.dead == false) attachGame(st)
                })
                Layer(d.key, d.sig, f)
            }
            SourceType.CAMERA -> {
                val f = SurfaceFilterRender(SurfaceFilterRender.SurfaceReadyCallback { st ->
                    holder[0]?.let { if (!it.dead) startCamera(it, st) }
                })
                Layer(d.key, d.sig, f)
            }
            SourceType.IMAGE -> {
                val f = ImageObjectFilterRender()
                val l = Layer(d.key, d.sig, f)
                loadImageAsync(l, f, src.contentUri.orEmpty())
                l
            }
            SourceType.TEXT -> {
                val f = ImageObjectFilterRender()
                f.setImage(renderText(src))
                Layer(d.key, d.sig, f)
            }
            SourceType.WEB -> {
                val f = AndroidViewFilterRender()
                val l = Layer(d.key, d.sig, f)
                l.web = webHost.create(
                    target = src.contentUri.orEmpty(),
                    isLocalFile = src.webMode == 1,
                    cssW = cssDim(src.width, canvasW),
                    cssH = cssDim(src.height, canvasH),
                    onLaidOut = { wv -> if (!l.dead) { f.setView(wv); place(l) } },
                    onProblem = { msg -> onNotice?.invoke(msg) }
                )
                l
            }
        }
        holder[0] = layer
        layer.src = src
        layers.add(layer)
        gl.addFilter(layer.filter)
        place(layer)
    }

    private fun removeLayer(l: Layer, gl: GlStreamInterface) {
        l.dead = true
        // Urutan penting: hentikan produsen frame dulu, baru lepas filter (yang melepas SurfaceTexture)
        l.camera?.stop()
        l.camera = null
        webHost.destroy(l.web)
        l.web = null
        if (l.key == "SCREEN") {
            try { virtualDisplay?.setSurface(null) } catch (_: Exception) {}
            try { gameSurface?.release() } catch (_: Exception) {}
            gameSurface = null
        }
        try { gl.removeFilter(l.filter) } catch (e: Exception) { Log.w(tag, "removeFilter: ${e.message}") }
        layers.remove(l)
    }

    private fun place(l: Layer) {
        val src = l.src ?: return
        val f = l.filter
        when (f) {
            is BaseObjectFilterRender -> {
                f.setScale(src.width * 100f, src.height * 100f)
                f.setPosition(src.x * 100f, src.y * 100f)
                f.setAlpha(src.opacity.coerceIn(0f, 1f))
                f.setRotation(rotationFor(l, src))
            }
            is AndroidViewFilterRender -> {
                f.setScale(src.width * 100f, src.height * 100f)
                f.setPosition(src.x * 100f, src.y * 100f)
            }
        }
    }

    private fun rotationFor(l: Layer, src: SourceEntity): Int {
        val user = src.rotation.roundToInt()
        val cam = l.camera
        val auto = if (l.key == "CAMERA" && cam != null) {
            val disp = displayRotationDegrees()
            if (cam.isFront) (cam.sensorOrientation + disp) % 360
            else (cam.sensorOrientation - disp + 360) % 360
        } else 0
        return ((auto + user) % 360 + 360) % 360
    }

    @Suppress("DEPRECATION")
    private fun displayRotationDegrees(): Int {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return wm.defaultDisplay.rotation * 90
    }

    // ---------------------------------------------------------------- game capture

    private fun attachGame(st: SurfaceTexture) {
        val mp = projection ?: return
        val (w, h) = captureSize()
        capW = w
        capH = h
        onCaptureAspect?.invoke(w.toFloat() / h)
        val surface = try {
            st.setDefaultBufferSize(w, h)
            Surface(st)
        } catch (e: Exception) {
            Log.w(tag, "SurfaceTexture game sudah dilepas: ${e.message}")
            return
        }
        val old = gameSurface
        gameSurface = surface
        val vd = virtualDisplay
        try {
            if (vd == null) {
                // createVirtualDisplay hanya boleh SEKALI per token MediaProjection (Android 14+)
                val thread = HandlerThread("VilichtVD").also { it.start() }
                vdThread = thread
                virtualDisplay = mp.createVirtualDisplay(
                    "VilichtGame", w, h, context.resources.displayMetrics.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    if (gameCaptureActive) surface else null, null, Handler(thread.looper)
                )
            } else {
                // Layer game dibuat ulang (urutan z berubah): pindahkan output ke surface baru
                vd.setSurface(if (gameCaptureActive) surface else null)
            }
        } catch (e: Exception) {
            Log.e(tag, "createVirtualDisplay gagal: ${e.message}", e)
            onError?.invoke("Capture layar gagal: ${e.localizedMessage}")
            return
        }
        try { old?.release() } catch (_: Exception) {}
    }

    /**
     * Mode editor. active=false: jeda capture layar (layer game membeku di frame terakhir).
     * active=true: lanjutkan capture. Tidak menyentuh encoder, RTMP, kamera, maupun overlay.
     */
    fun setGameCaptureActive(active: Boolean) {
        gameCaptureActive = active
        val vd = virtualDisplay ?: return
        try {
            vd.setSurface(if (active) gameSurface else null)
        } catch (e: Exception) {
            Log.w(tag, "setSurface($active) gagal: ${e.message}")
        }
    }

    /** Dipanggil saat rotasi layar berubah: sesuaikan ukuran capture dan rotasi kamera. */
    fun onDisplayChanged() {
        layers.firstOrNull { it.key == "CAMERA" }?.let { place(it) }
        val vd = virtualDisplay ?: return
        val (w, h) = captureSize()
        if (w == capW && h == capH) return
        capW = w
        capH = h
        onCaptureAspect?.invoke(w.toFloat() / h)
        try {
            vd.resize(w, h, context.resources.displayMetrics.densityDpi)
            (layers.firstOrNull { it.key == "SCREEN" }?.filter as? SurfaceFilterRender)
                ?.surfaceTexture?.setDefaultBufferSize(w, h)
        } catch (e: Exception) {
            Log.w(tag, "resize gagal: ${e.message}")
        }
    }

    // ---------------------------------------------------------------- kamera

    private fun startCamera(l: Layer, st: SurfaceTexture) {
        val cam = CameraLayerSource(context) { msg -> if (msg.isNotEmpty()) main.post { onNotice?.invoke(msg) } }
        l.camera = cam
        cam.start(st, l.src?.cameraId, fps)
        place(l) // rotasi kamera bergantung pada sensor kamera yang baru dibuka
    }

    // ---------------------------------------------------------------- gambar & teks

    private fun loadImageAsync(l: Layer, f: ImageObjectFilterRender, path: String) {
        decoder.execute {
            val bmp = try { decodeBitmap(path, 1280) } catch (e: Throwable) {
                Log.e(tag, "decode gambar gagal: ${e.message}"); null
            }
            main.post {
                if (bmp == null) { onNotice?.invoke("Gambar overlay tidak bisa dibuka."); return@post }
                if (l.dead) bmp.recycle() else f.setImage(bmp)
            }
        }
    }

    private fun decodeBitmap(path: String, maxSide: Int): Bitmap? {
        fun openStream() = if (path.startsWith("content:") || path.startsWith("file:"))
            context.contentResolver.openInputStream(Uri.parse(path)) else java.io.File(path).inputStream()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        openStream()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > maxSide * 2 || bounds.outHeight / sample > maxSide * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return openStream()?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    /** Teks dirender ke bitmap sekali; rumus ukuran font sama dengan editor supaya hasilnya konsisten. */
    private fun renderText(src: SourceEntity): Bitmap {
        val w = (src.width * canvasW).roundToInt().coerceIn(32, 1280)
        val h = (src.height * canvasH).roundToInt().coerceIn(16, 1280)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = src.textBgColor.toInt() }
        c.drawRoundRect(0f, 0f, w.toFloat(), h.toFloat(), 8f, 8f, bg)
        val text = src.textContent ?: "TEXT"
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = src.textColor.toInt()
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
            textSize = textSizePx(text, w.toFloat(), h.toFloat())
        }
        val y = h / 2f - (paint.ascent() + paint.descent()) / 2f
        c.drawText(text, w / 2f, y, paint)
        return bmp
    }

    // ---------------------------------------------------------------- preview Studio

    /** Tampilkan hasil komposisi (yang sama dengan yang dikirim ke RTMP) di SurfaceView Studio. */
    fun attachStudioPreview(surface: Surface, width: Int, height: Int) {
        val s = stream ?: return
        if (!surface.isValid || !s.isOnPreview) return
        try {
            studioSurface?.let { s.removeMultiPreviewSurface(it) }
            s.addPreviewSurface(
                surface,
                MultiPreviewConfig(
                    width = width, height = height,
                    aspectRatioMode = AspectRatioMode.Adjust,
                    isPortrait = canvasH > canvasW
                )
            )
            studioSurface = surface
        } catch (e: Exception) {
            Log.w(tag, "attachStudioPreview gagal: ${e.message}")
        }
    }

    fun detachStudioPreview(surface: Surface?) {
        val s = stream
        val target = surface ?: studioSurface
        if (s != null && target != null) {
            try { s.removeMultiPreviewSurface(target) } catch (_: Exception) {}
        }
        if (studioSurface === target) studioSurface = null
    }

    // ---------------------------------------------------------------- snapshot referensi

    /** Game dengan rasio aslinya, muat penuh di canvas dan di tengah. */
    private fun fitRect(): LayerRect {
        if (capW <= 0 || capH <= 0) return LayerRect(0f, 0f, 1f, 1f)
        val canvasAspect = canvasW.toFloat() / canvasH
        val gameAspect = capW.toFloat() / capH
        val w: Float
        val h: Float
        if (gameAspect > canvasAspect) { w = 1f; h = canvasAspect / gameAspect }
        else { h = 1f; w = gameAspect / canvasAspect }
        return LayerRect((1f - w) / 2f, (1f - h) / 2f, w, h)
    }

    /** Rect game (0..1) yang mempertahankan rasio layar asli. Dipakai tombol "Pas rasio" di editor. */
    fun fitGameRect(): LayerRect = fitRect()

    /**
     * Potret layar game saja (tanpa kamera/overlay), rasio asli, untuk referensi visual editor.
     * Ini hanya bitmap untuk editor; tidak pernah menjadi sumber video siaran.
     */
    fun captureGameSnapshot(onResult: (Bitmap?) -> Unit) {
        val s = stream
        val game = layers.firstOrNull { it.key == "SCREEN" }
        if (s == null || game == null || capW <= 0) { onResult(null); return }
        onDisplayChanged()
        val fit = fitRect()
        val gf = game.filter as? BaseObjectFilterRender
        gf?.setScale(fit.w * 100f, fit.h * 100f)
        gf?.setPosition(fit.x * 100f, fit.y * 100f)
        gf?.setAlpha(1f)
        hideOverlays(true)
        main.postDelayed({
            s.getGlInterface().takePhoto(TakePhotoCallback { bmp ->
                val out = try { cropTo(bmp, fit) } catch (e: Exception) {
                    Log.e(tag, "crop snapshot gagal: ${e.message}"); null
                }
                main.post {
                    hideOverlays(false)
                    place(game)
                    onResult(out)
                }
            })
        }, 250)
    }

    private fun hideOverlays(hide: Boolean) {
        for (l in layers) {
            if (l.key == "SCREEN") continue
            when (val f = l.filter) {
                is BaseObjectFilterRender -> f.setAlpha(if (hide) 0f else (l.src?.opacity ?: 1f))
                is AndroidViewFilterRender -> if (hide) f.setPosition(500f, 500f) else place(l)
            }
        }
    }

    private fun cropTo(src: Bitmap, r: LayerRect): Bitmap {
        val x = (r.x * src.width).toInt().coerceIn(0, src.width - 1)
        val y = (r.y * src.height).toInt().coerceIn(0, src.height - 1)
        val w = (r.w * src.width).toInt().coerceIn(1, src.width - x)
        val h = (r.h * src.height).toInt().coerceIn(1, src.height - y)
        return Bitmap.createBitmap(src, x, y, w, h)
    }

    // ---------------------------------------------------------------- siaran

    fun goLive(endpoint: String, audioBitrateBps: Int): Boolean {
        val s = stream ?: return false
        s.getStreamClient().setReTries(10)
        if (!s.prepareAudio(44100, true, audioBitrateBps)) return false
        s.startStream(endpoint)
        return true
    }

    fun retry(delayMs: Long, reason: String): Boolean =
        stream?.getStreamClient()?.reTry(delayMs, reason) == true

    fun stopLive() {
        val s = stream ?: return
        if (s.isStreaming) s.stopStream()
    }

    /** Statistik nyata dari klien RTMP; null kalau belum ada stream. */
    fun counters(): EngineCounters? {
        val c = stream?.getStreamClient() ?: return null
        return EngineCounters(c.getSentVideoFrames(), c.getDroppedVideoFrames(), c.getBytesSend())
    }

    /** Jeda = layar hitam + audio senyap, siaran tetap tersambung. */
    fun setPaused(paused: Boolean) {
        com.example.audio.StreamAudioParams.paused = paused
        val gl = stream?.getGlInterface() ?: return
        if (paused) gl.muteVideo() else gl.unMuteVideo()
    }

    fun release() {
        main.removeCallbacks(reconcileRunnable)
        for (l in layers.toList()) {
            l.dead = true
            l.camera?.stop(); l.camera = null
            webHost.destroy(l.web); l.web = null
        }
        layers.clear()
        desired = emptyList()
        detachStudioPreview(null)
        try { stream?.release() } catch (e: Exception) { Log.w(tag, "release stream: ${e.message}") }
        stream = null
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { gameSurface?.release() } catch (_: Exception) {}
        gameSurface = null
        vdThread?.quitSafely()
        vdThread = null
        try { previewReader?.close() } catch (_: Exception) {}
        previewReader = null
        projection?.let {
            try { it.unregisterCallback(projectionCallback) } catch (_: Exception) {}
            try { it.stop() } catch (_: Exception) {}
        }
        projection = null
        capW = 0
        capH = 0
        currentFps = 0
        gameCaptureActive = true
    }

    /** Matikan pool decoder gambar; dipanggil sekali saat service dihancurkan. */
    fun shutdown() {
        decoder.shutdownNow()
    }

    private fun captureSize(): Pair<Int, Int> {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        var rw: Int
        var rh: Int
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.maximumWindowMetrics.bounds
            rw = b.width(); rh = b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            rw = dm.widthPixels; rh = dm.heightPixels
        }
        // Batasi sisi terpanjang supaya ringan, jaga rasio, dan pastikan genap
        val maxSide = 1280f
        val scale = minOf(1f, maxSide / maxOf(rw, rh))
        rw = (rw * scale).toInt() and 1.inv()
        rh = (rh * scale).toInt() and 1.inv()
        return maxOf(rw, 2) to maxOf(rh, 2)
    }

    companion object {
        /** Ukuran viewport CSS Browser Source (kelipatan 16) dari fraksi canvas. */
        fun cssDim(fraction: Float, canvasPx: Int): Int =
            ((fraction * canvasPx / 16f).roundToInt() * 16).coerceIn(64, 3840)

        /** Rumus ukuran font teks overlay; dipakai bersama oleh GL dan editor agar konsisten. */
        fun textSizePx(text: String, w: Float, h: Float): Float =
            min(h * 0.55f, w * 0.92f / (max(1, text.length) * 0.58f))
    }
}
