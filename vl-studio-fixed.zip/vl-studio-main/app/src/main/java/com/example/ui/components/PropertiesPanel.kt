package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SourceEntity
import com.example.data.model.SourceType
import com.example.ui.theme.*

@Composable
fun PropertiesPanel(
    selectedSource: SourceEntity?,
    onUpdateSource: (SourceEntity) -> Unit,
    cameras: List<com.example.engine.CameraInfo> = emptyList(),
    defaultCameraId: String? = null,
    onSetCamera: (String?) -> Unit = {},
    onFitGame: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Surface(
        color = CharcoalPanel,
        modifier = modifier
            .width(260.dp)
            .fillMaxHeight()
            .border(1.dp, CharcoalBorder)
            .testTag("studio_properties_panel")
    ) {
        if (selectedSource == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Pilih source untuk mengatur\nposisi, ukuran, dan kamera",
                    color = TextMuted,
                    fontSize = 12.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "TRANSFORM",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Badge(containerColor = CharcoalSurface) {
                        Text(
                            text = selectedSource.type.name,
                            color = ChampagneGold,
                            fontSize = 10.sp
                        )
                    }
                }

                Text(
                    text = selectedSource.name,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                Divider(color = CharcoalBorder, thickness = 1.dp)

                // TEXT OVERLAY CONTENT EDITOR
                if (selectedSource.type == SourceType.TEXT) {
                    Text(
                        text = "Text Content",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    OutlinedTextField(
                        value = selectedSource.textContent ?: "",
                        onValueChange = { onUpdateSource(selectedSource.copy(textContent = it)) },
                        modifier = Modifier.fillMaxWidth().testTag("text_content_input"),
                        singleLine = false,
                        maxLines = 2,
                        textStyle = LocalTextStyle.current.copy(fontSize = 12.sp, color = TextPrimary),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ChampagneGold,
                            unfocusedBorderColor = CharcoalBorder,
                            focusedContainerColor = CharcoalSurface,
                            unfocusedContainerColor = CharcoalSurface
                        )
                    )
                    Divider(color = CharcoalBorder, thickness = 1.dp)
                }

                // POSITION (X, Y)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Position", color = TextSecondary, fontSize = 11.sp)
                    Text(
                        text = "X: ${(selectedSource.x * 100).toInt()}%  Y: ${(selectedSource.y * 100).toInt()}%",
                        color = TextPrimary,
                        fontSize = 11.sp
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "X", color = TextMuted, fontSize = 10.sp)
                        Slider(
                            value = selectedSource.x,
                            onValueChange = { onUpdateSource(selectedSource.copy(x = it)) },
                            valueRange = 0f..0.9f,
                            colors = SliderDefaults.colors(
                                thumbColor = ChampagneGold,
                                activeTrackColor = ChampagneGold,
                                inactiveTrackColor = CharcoalBorder
                            )
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Y", color = TextMuted, fontSize = 10.sp)
                        Slider(
                            value = selectedSource.y,
                            onValueChange = { onUpdateSource(selectedSource.copy(y = it)) },
                            valueRange = 0f..0.9f,
                            colors = SliderDefaults.colors(
                                thumbColor = ChampagneGold,
                                activeTrackColor = ChampagneGold,
                                inactiveTrackColor = CharcoalBorder
                            )
                        )
                    }
                }

                // DIMENSIONS (WIDTH, HEIGHT)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Scale", color = TextSecondary, fontSize = 11.sp)
                    Text(
                        text = "W: ${(selectedSource.width * 100).toInt()}%  H: ${(selectedSource.height * 100).toInt()}%",
                        color = TextPrimary,
                        fontSize = 11.sp
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Width", color = TextMuted, fontSize = 10.sp)
                        Slider(
                            value = selectedSource.width,
                            onValueChange = { onUpdateSource(selectedSource.copy(width = it)) },
                            valueRange = 0.1f..1f,
                            colors = SliderDefaults.colors(
                                thumbColor = ChampagneGold,
                                activeTrackColor = ChampagneGold,
                                inactiveTrackColor = CharcoalBorder
                            )
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Height", color = TextMuted, fontSize = 10.sp)
                        Slider(
                            value = selectedSource.height,
                            onValueChange = { onUpdateSource(selectedSource.copy(height = it)) },
                            valueRange = 0.05f..1f,
                            colors = SliderDefaults.colors(
                                thumbColor = ChampagneGold,
                                activeTrackColor = ChampagneGold,
                                inactiveTrackColor = CharcoalBorder
                            )
                        )
                    }
                }

                // ROTATION & OPACITY
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Rotation", color = TextSecondary, fontSize = 11.sp)
                    Text(text = "${selectedSource.rotation.toInt()}°", color = TextPrimary, fontSize = 11.sp)
                }
                Slider(
                    value = selectedSource.rotation,
                    onValueChange = { onUpdateSource(selectedSource.copy(rotation = it)) },
                    valueRange = -180f..180f,
                    colors = SliderDefaults.colors(
                        thumbColor = ChampagneGold,
                        activeTrackColor = ChampagneGold,
                        inactiveTrackColor = CharcoalBorder
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Opacity", color = TextSecondary, fontSize = 11.sp)
                    Text(text = "${(selectedSource.opacity * 100).toInt()}%", color = TextPrimary, fontSize = 11.sp)
                }
                Slider(
                    value = selectedSource.opacity,
                    onValueChange = { onUpdateSource(selectedSource.copy(opacity = it)) },
                    valueRange = 0.1f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = ChampagneGold,
                        activeTrackColor = ChampagneGold,
                        inactiveTrackColor = CharcoalBorder
                    )
                )

                Divider(color = CharcoalBorder, thickness = 1.dp)

                // KUNCI RASIO + PENUHI CANVAS
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Kunci rasio saat resize", color = TextSecondary, fontSize = 11.sp)
                    Switch(
                        checked = selectedSource.aspectLocked,
                        onCheckedChange = { onUpdateSource(selectedSource.copy(aspectLocked = it)) },
                        colors = SwitchDefaults.colors(checkedTrackColor = ChampagneGold)
                    )
                }
                OutlinedButton(
                    onClick = { onUpdateSource(selectedSource.copy(x = 0f, y = 0f, width = 1f, height = 1f)) },
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                ) { Text("Penuhi canvas (fullscreen source)", fontSize = 11.sp, color = ChampagneGoldLight) }

                if (selectedSource.type == SourceType.SCREEN) {
                    OutlinedButton(
                        onClick = onFitGame,
                        modifier = Modifier.fillMaxWidth().height(44.dp)
                    ) { Text("Pas rasio layar game", fontSize = 11.sp, color = ChampagneGoldLight) }
                }

                // KAMERA: pilih kamera yang terdeteksi (depan, belakang, eksternal/USB)
                if (selectedSource.type == SourceType.CAMERA) {
                    Text("Kamera", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    if (cameras.isEmpty()) {
                        Text("Tidak ada kamera terdeteksi.", color = TextMuted, fontSize = 10.sp)
                    }
                    cameras.forEach { cam ->
                        val chosen = (selectedSource.cameraId ?: defaultCameraId) == cam.id
                        Surface(
                            color = if (chosen) CharcoalSurface else Color.Transparent,
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (chosen) ChampagneGold else CharcoalBorder),
                            modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp).clickable { onSetCamera(cam.id) }
                        ) {
                            Box(Modifier.padding(horizontal = 10.dp), contentAlignment = Alignment.CenterStart) {
                                Text(cam.label, color = if (chosen) TextPrimary else TextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }

                // BROWSER OVERLAY
                if (selectedSource.type == SourceType.WEB) {
                    if (selectedSource.webMode == 0) {
                        var urlDraft by remember(selectedSource.id) { mutableStateOf(selectedSource.contentUri ?: "") }
                        Text("URL Browser Source", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = urlDraft,
                            onValueChange = { urlDraft = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(fontSize = 12.sp, color = TextPrimary),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ChampagneGold, unfocusedBorderColor = CharcoalBorder,
                                focusedContainerColor = CharcoalSurface, unfocusedContainerColor = CharcoalSurface
                            )
                        )
                        Button(
                            onClick = { onUpdateSource(selectedSource.copy(contentUri = urlDraft.trim())) },
                            enabled = urlDraft.trim() != (selectedSource.contentUri ?: ""),
                            colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold, contentColor = CharcoalMain),
                            modifier = Modifier.fillMaxWidth().height(44.dp)
                        ) { Text("Terapkan URL", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    } else {
                        Text("Sumber: file HTML lokal yang diimpor", color = TextMuted, fontSize = 10.sp)
                    }
                    Text(
                        "Background transparan didukung. Opacity tidak berlaku untuk Browser Overlay. " +
                            "Ukuran viewport mengikuti ukuran source di canvas.",
                        color = TextMuted, fontSize = 10.sp
                    )
                }

                if (selectedSource.isReference) {
                    Text(
                        "Screenshot referensi: hanya tampil di editor, tidak ikut ke siaran.",
                        color = ChampagneGoldLight, fontSize = 10.sp
                    )
                }
            }
        }
    }
}
