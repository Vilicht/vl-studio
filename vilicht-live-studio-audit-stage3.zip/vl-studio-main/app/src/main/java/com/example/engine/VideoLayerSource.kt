package com.example.engine

import android.content.Context
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.util.Log
import android.view.Surface

/**
 * Video (file lokal) -> SurfaceTexture milik layer GL, diputar berulang (loop).
 * Suara video SENGAJA dibisukan: audio video belum dicampur ke mixer siaran, dan tanpa dibisukan
 * ia hanya akan terdengar di speaker perangkat, bukan di siaran.
 * Harus dibuat dan dihentikan dari Main Thread; stop() dipanggil SEBELUM SurfaceTexture dilepas.
 */
class VideoLayerSource(
    @Suppress("unused") private val context: Context,
    private val onSize: (Int, Int) -> Unit,
    private val onError: (String) -> Unit
) {
    private val tag = "VilichtVideo"
    private var player: MediaPlayer? = null
    private var surface: Surface? = null

    fun start(st: SurfaceTexture, path: String) {
        stop()
        try {
            val s = Surface(st)
            surface = s
            val mp = MediaPlayer()
            player = mp
            mp.setSurface(s)
            mp.setDataSource(path)
            mp.isLooping = true
            mp.setVolume(0f, 0f)
            mp.setOnVideoSizeChangedListener { _, w, h -> if (w > 0 && h > 0) onSize(w, h) }
            mp.setOnErrorListener { _, what, extra ->
                Log.e(tag, "MediaPlayer error $what/$extra")
                onError("Video tidak bisa diputar (kode $what/$extra).")
                true
            }
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
        } catch (e: Exception) {
            Log.e(tag, "start gagal: ${e.message}", e)
            onError("Video gagal dibuka: ${e.localizedMessage}")
            stop()
        }
    }

    fun stop() {
        val mp = player
        player = null
        if (mp != null) {
            try { mp.setOnPreparedListener(null) } catch (_: Exception) {}
            try { mp.setOnErrorListener(null) } catch (_: Exception) {}
            try { mp.stop() } catch (_: Exception) {}
            try { mp.release() } catch (_: Exception) {}
        }
        try { surface?.release() } catch (_: Exception) {}
        surface = null
    }
}
