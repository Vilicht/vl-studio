package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// VILICHT Studio Charcoal & Warm-Neutral Palette
val CharcoalMain = Color(0xFF0F0D14)
val CharcoalSecondary = Color(0xFF16131E)
val CharcoalPanel = Color(0xFF1D1A27)
val CharcoalSurface = Color(0xFF272333)
val CharcoalBorder = Color(0xFF3A3548)

val TextPrimary = Color(0xFFF3F0FA)
val TextSecondary = Color(0xFFB1ABC4)
val TextMuted = Color(0xFF7C768F)

// Accents (nama 'ChampagneGold*' dipertahankan agar tidak mengubah seluruh file; nilainya kini ungu)
val Accent get() = ChampagneGold
val ChampagneGold = Color(0xFFA855F7)
val ChampagneGoldLight = Color(0xFFC084FC)
val ChampagneGoldDark = Color(0xFF7E22CE)

// Semantic
val StatusGreen = Color(0xFF5B8A64)
val StatusAmber = Color(0xFFC49B4B)
val StatusRed = Color(0xFFB24A4A)
val StatusBlue = Color(0xFF5C7E9C)
