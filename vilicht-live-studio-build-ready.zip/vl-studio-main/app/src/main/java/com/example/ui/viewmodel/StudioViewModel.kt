package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.BitmapFactory
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Surface
import androidx.room.withTransaction
import com.example.audio.AudioDeviceMonitor
import com.example.engine.CameraInfo
import com.example.engine.CameraLayerSource
import com.example.engine.LocalOverlayStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioMixerController
import com.example.audio.StreamAudioParams
import com.example.data.db.StudioDatabase
import com.example.data.model.AudioSettingsEntity
import com.example.data.model.SceneEntity
import com.example.data.model.SourceEntity
import com.example.data.model.SourceType
import com.example.data.model.StreamProfileEntity
import com.example.data.repository.StudioRepository
import com.example.encoder.AutoDetectionResult
import com.example.encoder.DeviceCapabilityDetector
import com.example.encoder.StreamKeyStorage
import com.example.encoder.StreamPreset
import android.content.Intent
import com.example.service.CameraPreviewState
import com.example.service.LiveStudioState
import kotlin.math.abs
import kotlin.math.min
import com.example.service.StreamingService
import com.example.service.StreamingStatus
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.max

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val db = StudioDatabase.getInstance(application)
    private val repository = StudioRepository(
        db.sceneDao(),
        db.sourceDao(),
        db.streamProfileDao(),
        db.audioSettingsDao()
    )

    val audioMixer = AudioMixerController(application)
    val audioDevices = AudioDeviceMonitor(application)
    val autoDetection: AutoDetectionResult = DeviceCapabilityDetector.detectOptimalPreset(application)

    val allScenes: StateFlow<List<SceneEntity>> = repository.allScenes
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val selectedScene: StateFlow<SceneEntity?> = repository.selectedScene
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _selectedSourceId = MutableStateFlow<String?>(null)
    val selectedSourceId: StateFlow<String?> = _selectedSourceId.asStateFlow()

    val currentSources: StateFlow<List<SourceEntity>> = selectedScene
        .flatMapLatest { scene ->
            if (scene != null) repository.getSourcesForScene(scene.id)
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val selectedSource: StateFlow<SourceEntity?> = combine(currentSources, _selectedSourceId) { list, id ->
        list.find { it.id == id } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val allProfiles: StateFlow<List<StreamProfileEntity>> = repository.allProfiles
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val selectedProfile: StateFlow<StreamProfileEntity?> = repository.selectedProfile
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val audioSettings: StateFlow<AudioSettingsEntity?> = repository.audioSettings
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val liveState: StateFlow<LiveStudioState> = StreamingService.studioState

    // UI dialog states
    val isSettingsOpen = MutableStateFlow(false)
    val isPermissionsOpen = MutableStateFlow(false)
    val isDiagnosticsOpen = MutableStateFlow(false)
    val isAddSourceOpen = MutableStateFlow(false)
    val isAddSceneOpen = MutableStateFlow(false)
    val isEditProfileOpen = MutableStateFlow(false)
    val isAudioDevicesOpen = MutableStateFlow(false)

    /** Pesan singkat untuk pengguna (toast). Activity mengonsumsinya lalu memanggil consumeMessage(). */
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()
    fun consumeMessage() { _message.value = null }
    private fun say(msg: String) { _message.value = msg }

    // ---- Kamera yang terdeteksi (termasuk USB/eksternal)
    private val _cameras = MutableStateFlow<List<CameraInfo>>(emptyList())
    val cameras: StateFlow<List<CameraInfo>> = _cameras.asStateFlow()
    fun refreshCameras() { _cameras.value = CameraLayerSource.listCameras(getApplication()) }
    private val cameraAvailability = object : CameraManager.AvailabilityCallback() {
        override fun onCameraAvailable(cameraId: String) { refreshCameras() }
        override fun onCameraUnavailable(cameraId: String) { refreshCameras() }
    }

    // ---- Undo / Redo (per scene)
    private val undoStack = ArrayDeque<List<SourceEntity>>()
    private val redoStack = ArrayDeque<List<SourceEntity>>()
    private val _canUndo = MutableStateFlow(false)
    private val _canRedo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()
    private var lastPushAt = 0L

    private fun pushUndo() {
        undoStack.addLast(currentSources.value)
        while (undoStack.size > 50) undoStack.removeFirst()
        redoStack.clear()
        lastPushAt = System.currentTimeMillis()
        syncUndoFlags()
    }
    /** Slider/ketikan berturut-turut dihitung satu langkah undo. */
    private fun pushUndoCoalesced() {
        if (System.currentTimeMillis() - lastPushAt > 800) pushUndo()
    }
    private fun syncUndoFlags() { _canUndo.value = undoStack.isNotEmpty(); _canRedo.value = redoStack.isNotEmpty() }
    private fun clearHistory() { undoStack.clear(); redoStack.clear(); syncUndoFlags() }

    /** Dipanggil kanvas saat drag/resize dimulai: satu gestur = satu langkah undo. */
    fun beginEdit() = pushUndo()

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(currentSources.value)
        restore(prev)
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(currentSources.value)
        restore(next)
    }

    private fun restore(list: List<SourceEntity>) {
        val scene = selectedScene.value ?: return
        syncUndoFlags()
        viewModelScope.launch { db.withTransaction { repository.replaceSources(scene.id, list) } }
    }

    // ---- Transformasi langsung dari kanvas (tanpa menunggu database)
    private val overrides = HashMap<String, SourceEntity>()

    private fun isEngineActive(st: StreamingStatus) =
        liveState.value.cameraPreview != CameraPreviewState.OFF ||
        st == StreamingStatus.PREVIEW || st == StreamingStatus.LIVE || st == StreamingStatus.PAUSED ||
            st == StreamingStatus.CONNECTING || st == StreamingStatus.RECONNECTING

    private fun pushSceneToEngine() {
        if (!isEngineActive(liveState.value.status)) return
        StreamingService.activeServiceInstance?.applyScene(currentSources.value.map { overrides[it.id] ?: it })
    }

    fun previewTransform(updated: SourceEntity) {
        overrides[updated.id] = updated
        pushSceneToEngine()
    }

    fun commitTransform(updated: SourceEntity) {
        viewModelScope.launch {
            repository.updateSource(updated)
            overrides.remove(updated.id)
        }
    }

    // ---- Preview Studio & mode editor
    fun attachPreview(surface: Surface, w: Int, h: Int) {
        StreamingService.activeServiceInstance?.attachStudioPreview(surface, w, h)
    }
    fun detachPreview(surface: Surface) {
        StreamingService.activeServiceInstance?.detachStudioPreview(surface)
    }
    fun setEditorVisible(visible: Boolean) {
        StreamingService.activeServiceInstance?.setEditorVisible(visible)
    }

    // Active preset
    val currentPreset = MutableStateFlow(autoDetection.selectedPreset)

    init {
        viewModelScope.launch {
            repository.initializeDefaultsIfNeeded()
            audioMixer.startMonitoring()
        }
        audioDevices.start()
        refreshCameras()
        StreamingService.contentAspectListener = { id, a -> onContentAspect(id, a) }
        try {
            (application.getSystemService(Context.CAMERA_SERVICE) as CameraManager)
                .registerAvailabilityCallback(cameraAvailability, Handler(Looper.getMainLooper()))
        } catch (_: Exception) {}

        // Seluruh source scene -> compositor GL (posisi, ukuran, urutan z, konten). Hanya saat status
        // berubah atau source berubah; update statistik tiap detik TIDAK memicu apa pun di sini.
        viewModelScope.launch {
            combine(currentSources, liveState.map { it.status to it.cameraPreview }.distinctUntilChanged()) { srcs, st -> srcs to st.first }
                .collect { (srcs, st) ->
                    if (isEngineActive(st)) {
                        StreamingService.activeServiceInstance
                            ?.applyScene(srcs.map { overrides[it.id] ?: it })
                    }
                }
        }
    }

    fun selectScene(scene: SceneEntity) {
        viewModelScope.launch {
            repository.selectScene(scene.id)
            _selectedSourceId.value = null
            clearHistory()
        }
    }

    fun renameScene(scene: SceneEntity, name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        viewModelScope.launch { repository.renameScene(scene, n) }
    }

    fun createScene(name: String, isPortrait: Boolean = false) {
        viewModelScope.launch {
            val scene = repository.createScene(name, isPortrait)
            repository.selectScene(scene.id)
        }
    }

    fun duplicateScene(scene: SceneEntity) {
        viewModelScope.launch {
            val duplicated = repository.duplicateScene(scene)
            repository.selectScene(duplicated.id)
        }
    }

    fun deleteScene(scene: SceneEntity) {
        if (allScenes.value.size <= 1) { say("Minimal harus ada satu scene."); return }
        viewModelScope.launch {
            repository.sourcesOnce(scene.id).forEach { cleanupMedia(it, excludingScene = scene.id) }
            repository.deleteScene(scene.id)
            val remaining = allScenes.value.filter { it.id != scene.id }
            remaining.firstOrNull()?.let { repository.selectScene(it.id) }
        }
    }

    fun toggleCanvasOrientation() {
        val scene = selectedScene.value ?: return
        val newPortrait = !scene.isPortrait
        viewModelScope.launch {
            repository.updateScene(
                scene.copy(
                    isPortrait = newPortrait,
                    canvasWidth = if (newPortrait) 720 else 1280,
                    canvasHeight = if (newPortrait) 1280 else 720
                )
            )
        }
    }

    fun selectSource(sourceId: String?) {
        _selectedSourceId.value = sourceId
    }

    private fun canvasPx(): Pair<Float, Float> {
        val sc = selectedScene.value
        return (sc?.canvasWidth ?: 1280).toFloat() to (sc?.canvasHeight ?: 720).toFloat()
    }

    private fun nextZ() = (currentSources.value.maxOfOrNull { it.zIndex } ?: 0) + 1

    fun addSource(name: String, type: SourceType, textContent: String? = null) {
        val scene = selectedScene.value ?: return
        val (w, h, x, y) = when (type) {
            SourceType.SCREEN -> listOf(1f, 1f, 0f, 0f)
            // Kamera 16:9 piksel, di pojok kanan bawah
            SourceType.CAMERA -> listOf(0.28f, 0.28f, 0.70f, 0.68f)
            SourceType.TEXT -> listOf(0.4f, 0.1f, 0.05f, 0.05f)
            SourceType.IMAGE -> listOf(0.3f, 0.3f, 0.35f, 0.35f)
            SourceType.WEB -> listOf(1f, 1f, 0f, 0f)
        }
        val source = SourceEntity(
            sceneId = scene.id, name = name, type = type, zIndex = nextZ(),
            x = x, y = y, width = w, height = h,
            textContent = textContent ?: if (type == SourceType.TEXT) "STREAM TITLE" else null,
            aspectLocked = type == SourceType.CAMERA,
            // Kamera depan ditampilkan seperti cermin (selfie); pengguna bisa mematikannya lewat Flip
            flipH = type == SourceType.CAMERA && isDefaultCameraFront(),
            contentAspect = if (type == SourceType.CAMERA) 16f / 9f else 0f
        )
        insertSource(source)
        if (type == SourceType.CAMERA) _cameraRequested.value = true
    }

    private fun insertSource(source: SourceEntity) {
        pushUndo()
        viewModelScope.launch {
            repository.addSource(source)
            _selectedSourceId.value = source.id
        }
    }

    /** Browser Source dari URL. */
    fun addWebUrl(name: String, url: String) {
        val scene = selectedScene.value ?: return
        val t = url.trim()
        if (t.isEmpty()) { say("URL kosong."); return }
        insertSource(
            SourceEntity(
                sceneId = scene.id, name = name.ifBlank { "Browser" }, type = SourceType.WEB, zIndex = nextZ(),
                x = 0f, y = 0f, width = 1f, height = 1f, contentUri = t, webMode = 0
            )
        )
    }

    /** Browser Source dari file HTML lokal (+ resource pendukung atau satu ZIP). */
    fun importLocalHtml(name: String, uris: List<Uri>) {
        val scene = selectedScene.value ?: return
        val id = UUID.randomUUID().toString()
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) {
                LocalOverlayStore.import(getApplication(), id, uris) { err -> say(err) }
            } ?: return@launch
            insertSource(
                SourceEntity(
                    id = id, sceneId = scene.id, name = name.ifBlank { "HTML Lokal" }, type = SourceType.WEB,
                    zIndex = nextZ(), x = 0f, y = 0f, width = 1f, height = 1f, contentUri = path, webMode = 1
                )
            )
        }
    }

    /** Gambar overlay, atau screenshot referensi (asReference=true: hanya editor, tidak ke RTMP). */
    fun importImage(uri: Uri, asReference: Boolean) {
        val scene = selectedScene.value ?: return
        val (cw, ch) = canvasPx()
        viewModelScope.launch {
            val copied = withContext(Dispatchers.IO) { copyImage(uri) }
            if (copied == null) { say("Gambar tidak bisa diimpor."); return@launch }
            val (path, iw, ih) = copied
            val imgAspect = iw.toFloat() / ih
            val canvasAspect = cw / ch
            val src = if (asReference) {
                val (w, h) = if (imgAspect > canvasAspect) 1f to (cw / imgAspect) / ch else ((ch * imgAspect) / cw) to 1f
                SourceEntity(
                    sceneId = scene.id, name = "Referensi", type = SourceType.IMAGE,
                    zIndex = (currentSources.value.minOfOrNull { it.zIndex } ?: 0) - 1,
                    x = (1f - w) / 2f, y = (1f - h) / 2f, width = w, height = h,
                    opacity = 0.6f, contentUri = path, isReference = true, aspectLocked = true
                )
            } else {
                val w = 0.3f
                val h = (((w * cw) / imgAspect) / ch).coerceAtMost(1f)
                SourceEntity(
                    sceneId = scene.id, name = "Gambar", type = SourceType.IMAGE, zIndex = nextZ(),
                    x = 0.35f, y = 0.35f, width = w, height = h, contentUri = path, aspectLocked = true,
                    contentAspect = imgAspect
                )
            }
            insertSource(src)
        }
    }

    private fun copyImage(uri: Uri): Triple<String, Int, Int>? = try {
        val dir = File(getApplication<Application>().filesDir, "media").apply { mkdirs() }
        val out = File(dir, UUID.randomUUID().toString() + ".img")
        var total = 0L
        getApplication<Application>().contentResolver.openInputStream(uri)?.use { ins ->
            out.outputStream().use { os ->
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > 30L * 1024 * 1024) throw IllegalStateException("Gambar terlalu besar (maks 30 MB)")
                    os.write(buf, 0, n)
                }
            }
        }
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(out.absolutePath, b)
        if (b.outWidth <= 0 || b.outHeight <= 0) { out.delete(); null } else Triple(out.absolutePath, b.outWidth, b.outHeight)
    } catch (e: Exception) { null }

    /**
     * Hapus file media milik source hanya bila tidak ada source lain yang memakainya (mis. hasil duplikasi scene).
     * Dipanggil sebelum scene dihapus; baris milik scene itu sendiri tidak dihitung sebagai pemakai.
     */
    private suspend fun cleanupMedia(src: SourceEntity, excludingScene: String) {
        val path = src.contentUri ?: return
        if (!path.startsWith(getApplication<Application>().filesDir.canonicalPath)) return
        val inThisScene = repository.sourcesOnce(excludingScene).count { it.contentUri == path }
        if (repository.countUsing(path) - inThisScene > 0) return
        withContext(Dispatchers.IO) {
            try {
                if (src.type == SourceType.WEB && src.webMode == 1) File(path).parentFile?.deleteRecursively()
                else if (src.type == SourceType.IMAGE) File(path).delete()
            } catch (_: Exception) {}
        }
    }

    /** Ubah source mana pun (dipakai panel properti, tombol kunci/sembunyi, dsb). */
    fun updateSource(updated: SourceEntity, recordUndo: Boolean = true) {
        if (recordUndo) pushUndoCoalesced()
        viewModelScope.launch { repository.updateSource(updated) }
    }

    fun updateSelectedSource(transform: (SourceEntity) -> SourceEntity) {
        val current = selectedSource.value ?: return
        updateSource(transform(current))
    }

    fun toggleVisibility(src: SourceEntity) = updateSource(src.copy(isVisible = !src.isVisible))
    fun toggleLock(src: SourceEntity) = updateSource(src.copy(isLocked = !src.isLocked))

    fun deleteSource(source: SourceEntity) {
        pushUndo()
        viewModelScope.launch {
            repository.deleteSource(source.id)
            if (_selectedSourceId.value == source.id) _selectedSourceId.value = null
            // File media sengaja TIDAK dihapus di sini supaya Undo bisa memulihkan source; dibersihkan saat scene dihapus.
        }
    }

    fun duplicateSource(source: SourceEntity) {
        val scene = selectedScene.value ?: return
        insertSource(
            source.copy(
                id = UUID.randomUUID().toString(), sceneId = scene.id, name = "${source.name} (Copy)",
                x = source.x + 0.03f,
                y = source.y + 0.03f,
                zIndex = nextZ()
            )
        )
    }

    fun reorderSource(source: SourceEntity, bringForward: Boolean) {
        val sources = currentSources.value.filter { !it.isReference }.sortedBy { it.zIndex }
        val index = sources.indexOfFirst { it.id == source.id }
        if (index == -1) return
        val targetIndex = if (bringForward) index + 1 else index - 1
        if (targetIndex !in sources.indices) return
        val other = sources[targetIndex]
        pushUndo()
        // Tukar zIndex; kalau sama (data lama), pisahkan agar urutannya pasti berubah
        val a = other.zIndex + if (other.zIndex == source.zIndex) (if (bringForward) 1 else -1) else 0
        viewModelScope.launch {
            db.withTransaction {
                repository.updateSource(source.copy(zIndex = a))
                repository.updateSource(other.copy(zIndex = source.zIndex))
            }
        }
    }

    // ---- Transformasi layer (Properties Panel). Semua rumus di sini bekerja di ruang canvas piksel
    // supaya rasio tidak pernah terdistorsi, dan memakai kotak layer PENUH (x,y,width,height) + crop.

    private fun visW(s: SourceEntity) = s.width * (1f - s.cropLeft - s.cropRight).coerceAtLeast(0.01f)
    private fun visH(s: SourceEntity) = s.height * (1f - s.cropTop - s.cropBottom).coerceAtLeast(0.01f)

    /** Persen skala: 100% = area terlihat persis muat di dalam canvas (contain). */
    fun scalePercent(s: SourceEntity): Float {
        val (cw, ch) = canvasPx()
        val aspect = (visW(s) * cw) / (visH(s) * ch)
        val containW = if (aspect >= cw / ch) 1f else aspect * ch / cw
        return visW(s) / containW * 100f
    }

    /** Skala proporsional di sekitar pusat layer; lebar dan tinggi berubah bersama, tidak ada distorsi. */
    fun setScalePercent(s: SourceEntity, percent: Float) {
        val (cw, ch) = canvasPx()
        val aspect = (visW(s) * cw) / (visH(s) * ch)
        val containW = if (aspect >= cw / ch) 1f else aspect * ch / cw
        val newVisW = containW * percent.coerceIn(5f, 400f) / 100f
        val k = newVisW / visW(s)
        val cx = s.x + s.width / 2f
        val cy = s.y + s.height / 2f
        val nw = s.width * k
        val nh = s.height * k
        updateSource(s.copy(x = cx - nw / 2f, y = cy - nh / 2f, width = nw, height = nh))
    }

    fun fitToScreen(s: SourceEntity) {
        val (cw, ch) = canvasPx()
        val vw = visW(s); val vh = visH(s)
        val aspect = (vw * cw) / (vh * ch)
        val (fw, fh) = if (aspect >= cw / ch) 1f to (cw / ch) / aspect else (aspect * ch / cw) to 1f
        val k = fw / vw
        val nw = s.width * k
        val nh = s.height * k
        updateSource(
            s.copy(
                x = (1f - fw) / 2f - s.cropLeft * nw,
                y = (1f - fh) / 2f - s.cropTop * nh,
                width = nw, height = nh, rotation = 0f
            )
        )
    }

    fun centerSource(s: SourceEntity) {
        updateSource(
            s.copy(
                x = 0.5f - visW(s) / 2f - s.cropLeft * s.width,
                y = 0.5f - visH(s) / 2f - s.cropTop * s.height
            )
        )
    }

    /** Hapus crop dan kembalikan rasio asli konten (bila diketahui), pusat layer tetap. */
    fun resetCropAndRatio(s: SourceEntity) {
        val (cw, ch) = canvasPx()
        val cx = s.x + s.width / 2f
        val cy = s.y + s.height / 2f
        var w = s.width
        var h = s.height
        if (s.contentAspect > 0f) h = w * cw / (s.contentAspect * ch)
        updateSource(
            s.copy(
                x = cx - w / 2f, y = cy - h / 2f, width = w, height = h,
                cropLeft = 0f, cropTop = 0f, cropRight = 0f, cropBottom = 0f
            )
        )
    }

    fun toggleFlipH(s: SourceEntity) = updateSource(s.copy(flipH = !s.flipH))
    fun rotate90(s: SourceEntity) = updateSource(s.copy(rotation = ((s.rotation + 90f) % 360f + 360f) % 360f))
    fun setRotation(s: SourceEntity, deg: Float) = updateSource(s.copy(rotation = ((deg % 360f) + 360f) % 360f))

    /** Crop per sisi dalam pecahan 0..0.95. Dua sisi berlawanan tidak boleh menutup seluruh konten. */
    fun setCrop(s: SourceEntity, l: Float? = null, t: Float? = null, r: Float? = null, b: Float? = null) {
        var nl = (l ?: s.cropLeft).coerceIn(0f, 0.95f)
        var nt = (t ?: s.cropTop).coerceIn(0f, 0.95f)
        var nr = (r ?: s.cropRight).coerceIn(0f, 0.95f)
        var nb = (b ?: s.cropBottom).coerceIn(0f, 0.95f)
        if (nl + nr > 0.95f) { if (l != null) nl = 0.95f - nr else nr = 0.95f - nl }
        if (nt + nb > 0.95f) { if (t != null) nt = 0.95f - nb else nb = 0.95f - nt }
        updateSource(s.copy(cropLeft = nl, cropTop = nt, cropRight = nr, cropBottom = nb))
    }

    /** Rasio asli konten dilaporkan engine (kamera, setelah koreksi orientasi). */
    private fun onContentAspect(id: String, aspect: Float) {
        val s = currentSources.value.firstOrNull { it.id == id } ?: return
        if (abs(s.contentAspect - aspect) < 0.01f) return
        val (cw, ch) = canvasPx()
        val currentPx = (s.width * cw) / (s.height * ch)
        // Sesuaikan tinggi hanya bila pengguna belum mendistorsi layer (rasio sekarang = rasio lama)
        val untouched = s.contentAspect <= 0f || abs(currentPx - s.contentAspect) / s.contentAspect < 0.03f
        var u = s.copy(contentAspect = aspect)
        if (untouched) {
            val cy = s.y + s.height / 2f
            val nh = s.width * cw / (aspect * ch)
            u = u.copy(y = cy - nh / 2f, height = nh)
        }
        viewModelScope.launch { repository.updateSource(u) }
    }

    // ---- Kualitas kamera (disimpan; berlaku tanpa mengubah transformasi layer)
    private val cameraPrefs = application.getSharedPreferences("vl_camera", Context.MODE_PRIVATE)
    private val _cameraMaxPixels = MutableStateFlow(cameraPrefs.getInt("maxPixels", 1280 * 720))
    private val _cameraFps = MutableStateFlow(cameraPrefs.getInt("fps", 30))
    val cameraMaxPixels: StateFlow<Int> = _cameraMaxPixels.asStateFlow()
    val cameraFps: StateFlow<Int> = _cameraFps.asStateFlow()

    fun setCameraQuality(maxPixels: Int, fps: Int) {
        _cameraMaxPixels.value = maxPixels
        _cameraFps.value = fps
        cameraPrefs.edit().putInt("maxPixels", maxPixels).putInt("fps", fps).apply()
        if (liveState.value.cameraPreview != CameraPreviewState.OFF) {
            getApplication<Application>().startService(
                Intent(getApplication(), StreamingService::class.java).apply {
                    action = StreamingService.ACTION_CAMERA_SETTINGS
                    putExtra(StreamingService.EXTRA_CAMERA_MAX_PIXELS, maxPixels)
                    putExtra(StreamingService.EXTRA_FPS, fps)
                }
            )
        }
    }

    /** Pengguna menambah/memakai sumber kamera: Activity memintakan izin kamera secara kontekstual. */
    private val _cameraRequested = MutableStateFlow(false)
    val cameraRequested: StateFlow<Boolean> = _cameraRequested.asStateFlow()
    fun consumeCameraRequest() { _cameraRequested.value = false }

    private fun isDefaultCameraFront(): Boolean {
        val id = CameraLayerSource.pickDefaultId(getApplication()) ?: return false
        return _cameras.value.firstOrNull { it.id == id }?.facing ==
            android.hardware.camera2.CameraCharacteristics.LENS_FACING_FRONT
    }

    // ---- Kamera
    fun switchCamera() {
        val cam = currentSources.value.firstOrNull { it.type == SourceType.CAMERA && it.isVisible }
            ?: currentSources.value.firstOrNull { it.type == SourceType.CAMERA } ?: return
        val list = _cameras.value
        if (list.isEmpty()) { say("Tidak ada kamera terdeteksi."); return }
        val currentId = cam.cameraId ?: CameraLayerSource.pickDefaultId(getApplication())
        val idx = list.indexOfFirst { it.id == currentId }
        val next = list[(idx + 1).mod(list.size)]
        updateSource(cam.copy(cameraId = next.id))
        say("Kamera: ${next.label}")
    }

    fun setCameraId(source: SourceEntity, id: String?) = updateSource(source.copy(cameraId = id))

    /** Game muat dengan rasio aslinya di tengah canvas. */
    fun fitGame(source: SourceEntity) {
        val aspect = liveState.value.captureAspect
        val (cw, ch) = canvasPx()
        if (aspect <= 0f) { say("Mulai siaran dulu agar rasio layar game diketahui."); return }
        val canvasAspect = cw / ch
        val (w, h) = if (aspect > canvasAspect) 1f to canvasAspect / aspect else (aspect / canvasAspect) to 1f
        updateSource(source.copy(x = (1f - w) / 2f, y = (1f - h) / 2f, width = w, height = h))
    }

    fun clearGameSnapshot() { resumePreview() }

    fun selectPreset(preset: StreamPreset) {
        currentPreset.value = preset
        val profile = selectedProfile.value
        if (profile != null) {
            viewModelScope.launch {
                repository.updateProfile(
                    profile.copy(
                        width = preset.width,
                        height = preset.height,
                        fps = preset.fps,
                        bitrateKbps = preset.defaultBitrateKbps,
                        isAutoMode = false
                    )
                )
            }
        }
    }

    fun setAutoPresetMode() {
        currentPreset.value = autoDetection.selectedPreset
        val profile = selectedProfile.value
        if (profile != null) {
            viewModelScope.launch {
                repository.updateProfile(
                    profile.copy(
                        width = autoDetection.selectedPreset.width,
                        height = autoDetection.selectedPreset.height,
                        fps = autoDetection.selectedPreset.fps,
                        bitrateKbps = autoDetection.selectedPreset.defaultBitrateKbps,
                        isAutoMode = true
                    )
                )
            }
        }
    }

    fun saveProfile(profile: StreamProfileEntity, plainStreamKey: String) {
        val encryptedKey = StreamKeyStorage.encrypt(plainStreamKey)
        viewModelScope.launch {
            repository.saveProfile(profile.copy(encryptedStreamKey = encryptedKey))
        }
    }

    fun selectProfile(profileId: String) {
        viewModelScope.launch {
            repository.selectProfile(profileId)
        }
    }

    fun resumePreview() {
        StreamingService.activeServiceInstance?.resumePreview()
    }

    fun toggleMicMute() {
        audioMixer.isMicMuted = !audioMixer.isMicMuted
        val settings = audioSettings.value ?: AudioSettingsEntity()
        viewModelScope.launch {
            repository.saveAudioSettings(settings.copy(isMicMuted = audioMixer.isMicMuted))
        }
        StreamAudioParams.micMuted = audioMixer.isMicMuted
        StreamingService.activeServiceInstance?.setMicMuted(audioMixer.isMicMuted)
    }

    fun updateMicVolume(volume: Float) {
        audioMixer.micGain = volume
        StreamAudioParams.micGain = volume
        val settings = audioSettings.value ?: AudioSettingsEntity()
        viewModelScope.launch {
            repository.saveAudioSettings(settings.copy(micVolume = volume))
        }
    }

    fun updateSystemVolume(volume: Float) {
        audioMixer.systemVolume = volume
        StreamAudioParams.systemVolume = volume
        val settings = audioSettings.value ?: AudioSettingsEntity()
        viewModelScope.launch {
            repository.saveAudioSettings(settings.copy(systemVolume = volume))
        }
    }

    fun getDecryptedKey(encrypted: String): String {
        return StreamKeyStorage.decrypt(encrypted)
    }

    override fun onCleared() {
        super.onCleared()
        try {
            (getApplication<Application>().getSystemService(Context.CAMERA_SERVICE) as CameraManager)
                .unregisterAvailabilityCallback(cameraAvailability)
        } catch (_: Exception) {}
        StreamingService.contentAspectListener = null
        audioDevices.stop()
        audioMixer.stopMonitoring()
    }
}
