package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SourceEntity
import com.example.data.model.SourceType
import com.example.ui.theme.*

@Composable
fun PropertiesPanel(
    selectedSource: SourceEntity?,
    onUpdateSource: (SourceEntity) -> Unit,
    /** Persen skala saat ini (100% = area terlihat persis muat di canvas). */
    scalePercent: Float = 100f,
    onScalePercent: (Float) -> Unit = {},
    onFit: () -> Unit = {},
    onCenter: () -> Unit = {},
    onResetCropAndRatio: () -> Unit = {},
    onToggleFlip: () -> Unit = {},
    onRotate90: () -> Unit = {},
    onSetRotation: (Float) -> Unit = {},
    onSetCrop: (left: Float?, top: Float?, right: Float?, bottom: Float?) -> Unit = { _, _, _, _ -> },
    cameras: List<com.example.engine.CameraInfo> = emptyList(),
    defaultCameraId: String? = null,
    onSetCamera: (String?) -> Unit = {},
    cameraMaxPixels: Int = 1280 * 720,
    cameraFps: Int = 30,
    onSetCameraQuality: (maxPixels: Int, fps: Int) -> Unit = { _, _ -> },
    onFitGame: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Surface(
        color = CharcoalPanel,
        modifier = modifier
            .width(260.dp)
            .fillMaxHeight()
            .border(1.dp, CharcoalBorder)
            .testTag("studio_properties_panel")
    ) {
        if (selectedSource == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Pilih source lalu atur\nposisi & ukuran langsung di canvas",
                    color = TextMuted,
                    fontSize = 12.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "TRANSFORM",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Badge(containerColor = CharcoalSurface) {
                        Text(
                            text = selectedSource.type.name,
                            color = ChampagneGold,
                            fontSize = 10.sp
                        )
                    }
                }

                Text(
                    text = selectedSource.name,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                Divider(color = CharcoalBorder, thickness = 1.dp)

                // TEXT OVERLAY CONTENT EDITOR
                if (selectedSource.type == SourceType.TEXT) {
                    Text(
                        text = "Text Content",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    OutlinedTextField(
                        value = selectedSource.textContent ?: "",
                        onValueChange = { onUpdateSource(selectedSource.copy(textContent = it)) },
                        modifier = Modifier.fillMaxWidth().testTag("text_content_input"),
                        singleLine = false,
                        maxLines = 2,
                        textStyle = LocalTextStyle.current.copy(fontSize = 12.sp, color = TextPrimary),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ChampagneGold,
                            unfocusedBorderColor = CharcoalBorder,
                            focusedContainerColor = CharcoalSurface,
                            unfocusedContainerColor = CharcoalSurface
                        )
                    )
                    Divider(color = CharcoalBorder, thickness = 1.dp)
                }

                val locked = selectedSource.isLocked
                val src = selectedSource

                // A. TRANSFORM QUICK ACTIONS. Posisi & ukuran diatur langsung di canvas (drag, handle sudut, handle sisi).
                SectionTitle("Transform")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    QuickAction(Icons.Default.FitScreen, "Fit", !locked, Modifier.weight(1f), "action_fit", onFit)
                    QuickAction(Icons.Default.CenterFocusStrong, "Center", !locked, Modifier.weight(1f), "action_center", onCenter)
                    QuickAction(Icons.Default.RestartAlt, "Reset crop & ratio", !locked, Modifier.weight(1f), "action_reset", onResetCropAndRatio)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    QuickAction(
                        Icons.Default.Flip, "Mirror", !locked, Modifier.weight(1f), "action_mirror",
                        onToggleFlip, active = src.flipH
                    )
                    QuickAction(
                        if (locked) Icons.Default.Lock else Icons.Default.LockOpen,
                        if (locked) "Unlock" else "Lock", true, Modifier.weight(1f), "action_lock",
                        { onUpdateSource(src.copy(isLocked = !locked)) }, active = locked
                    )
                }
                if (locked) Text("Layer terkunci. Buka kunci untuk mengubahnya.", color = TextMuted, fontSize = 10.sp)

                // B. SCALE: SATU slider proporsional. Lebar & tinggi berubah bersama, pusat layer tetap.
                var scaleDraft by remember(src.id) { mutableStateOf<Float?>(null) }
                val scaleShown = (scaleDraft ?: scalePercent).coerceIn(10f, 300f)
                LabeledValue("Scale", "${scaleShown.toInt()}%")
                GoldSlider(
                    value = scaleShown, range = 10f..300f, enabled = !locked, tag = "scale_slider",
                    onChange = { scaleDraft = it; onScalePercent(it) },
                    onFinished = { scaleDraft = null }
                )

                // C. ROTATION 0..360
                var rotDraft by remember(src.id) { mutableStateOf<Float?>(null) }
                val rotNorm = (((src.rotation % 360f) + 360f) % 360f)
                val rotShown = rotDraft ?: rotNorm
                LabeledValue("Rotation", "${rotShown.toInt()}°")
                GoldSlider(
                    value = rotShown, range = 0f..360f, enabled = !locked, tag = "rotation_slider",
                    onChange = { rotDraft = it; onSetRotation(it) },
                    onFinished = { rotDraft = null }
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    QuickAction(Icons.Default.Rotate90DegreesCw, "Rotate 90°", !locked, Modifier.weight(1f), "action_rotate90", onRotate90)
                    QuickAction(Icons.Default.RestartAlt, "Reset rotation", !locked && rotNorm != 0f, Modifier.weight(1f), "action_reset_rotation") { onSetRotation(0f) }
                }

                Divider(color = CharcoalBorder, thickness = 1.dp)

                // D. APPEARANCE
                SectionTitle("Appearance")
                LabeledValue("Opacity", "${(src.opacity * 100).toInt()}%")
                GoldSlider(
                    value = src.opacity, range = 0.1f..1f, enabled = true, tag = "opacity_slider",
                    onChange = { onUpdateSource(src.copy(opacity = it)) }
                )
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 44.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (src.isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff, null,
                            tint = TextSecondary, modifier = Modifier.size(16.dp)
                        )
                        Text("  Visible", color = TextSecondary, fontSize = 11.sp)
                    }
                    Switch(
                        checked = src.isVisible,
                        onCheckedChange = { onUpdateSource(src.copy(isVisible = it)) },
                        colors = SwitchDefaults.colors(checkedTrackColor = ChampagneGold),
                        modifier = Modifier.testTag("visible_switch")
                    )
                }
                Text(
                    "Blend mode tidak tersedia: compositor saat ini hanya mendukung alpha normal.",
                    color = TextMuted, fontSize = 9.sp
                )

                Divider(color = CharcoalBorder, thickness = 1.dp)

                // E. CROP: crop nyata per sisi (UV), terpisah dari Scale. Bisa juga ditarik dari handle sisi di canvas.
                SectionTitle("Crop")
                if (src.type == SourceType.WEB) {
                    Text("Crop tidak didukung untuk Browser Source.", color = TextMuted, fontSize = 10.sp)
                } else {
                    CropRow("Left", src.cropLeft, !locked, "crop_left") { onSetCrop(it, null, null, null) }
                    CropRow("Top", src.cropTop, !locked, "crop_top") { onSetCrop(null, it, null, null) }
                    CropRow("Right", src.cropRight, !locked, "crop_right") { onSetCrop(null, null, it, null) }
                    CropRow("Bottom", src.cropBottom, !locked, "crop_bottom") { onSetCrop(null, null, null, it) }
                }

                Divider(color = CharcoalBorder, thickness = 1.dp)

                if (selectedSource.type == SourceType.SCREEN) {
                    OutlinedButton(
                        onClick = onFitGame,
                        modifier = Modifier.fillMaxWidth().height(44.dp)
                    ) { Text("Pas rasio layar game", fontSize = 11.sp, color = ChampagneGoldLight) }
                }

                // KAMERA: pilih kamera yang terdeteksi (depan, belakang, eksternal/USB)
                if (selectedSource.type == SourceType.CAMERA) {
                    Text("Kamera", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    if (cameras.isEmpty()) {
                        Text("Tidak ada kamera terdeteksi.", color = TextMuted, fontSize = 10.sp)
                    }
                    cameras.forEach { cam ->
                        val chosen = (selectedSource.cameraId ?: defaultCameraId) == cam.id
                        Surface(
                            color = if (chosen) CharcoalSurface else Color.Transparent,
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (chosen) ChampagneGold else CharcoalBorder),
                            modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp).clickable { onSetCamera(cam.id) }
                        ) {
                            Box(Modifier.padding(horizontal = 10.dp), contentAlignment = Alignment.CenterStart) {
                                Text(cam.label, color = if (chosen) TextPrimary else TextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                    // Resolusi & FPS: berlaku tanpa mengubah posisi/ukuran/crop layer
                    Text("Resolusi", color = TextSecondary, fontSize = 11.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("480p" to 640 * 480, "720p" to 1280 * 720, "1080p" to 1920 * 1080).forEach { (label, px) ->
                            ChoiceChip(label, cameraMaxPixels == px, Modifier.weight(1f)) { onSetCameraQuality(px, cameraFps) }
                        }
                    }
                    Text("FPS", color = TextSecondary, fontSize = 11.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(15, 30, 60).forEach { f ->
                            ChoiceChip("$f", cameraFps == f, Modifier.weight(1f)) { onSetCameraQuality(cameraMaxPixels, f) }
                        }
                    }
                    Text(
                        "Mirror kamera: tombol Mirror di atas. Resolusi/FPS memakai nilai terdekat yang didukung kamera.",
                        color = TextMuted, fontSize = 9.sp
                    )
                }

                // BROWSER OVERLAY
                if (selectedSource.type == SourceType.WEB) {
                    if (selectedSource.webMode == 0) {
                        var urlDraft by remember(selectedSource.id) { mutableStateOf(selectedSource.contentUri ?: "") }
                        Text("URL Browser Source", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = urlDraft,
                            onValueChange = { urlDraft = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(fontSize = 12.sp, color = TextPrimary),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ChampagneGold, unfocusedBorderColor = CharcoalBorder,
                                focusedContainerColor = CharcoalSurface, unfocusedContainerColor = CharcoalSurface
                            )
                        )
                        Button(
                            onClick = { onUpdateSource(selectedSource.copy(contentUri = urlDraft.trim())) },
                            enabled = urlDraft.trim() != (selectedSource.contentUri ?: ""),
                            colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold, contentColor = CharcoalMain),
                            modifier = Modifier.fillMaxWidth().height(44.dp)
                        ) { Text("Terapkan URL", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    } else {
                        Text("Sumber: file HTML lokal yang diimpor", color = TextMuted, fontSize = 10.sp)
                    }
                    Text(
                        "Background transparan didukung. Opacity tidak berlaku untuk Browser Overlay. " +
                            "Ukuran viewport mengikuti ukuran source di canvas.",
                        color = TextMuted, fontSize = 10.sp
                    )
                }

                if (selectedSource.isReference) {
                    Text(
                        "Screenshot referensi: hanya tampil di editor, tidak ikut ke siaran.",
                        color = ChampagneGoldLight, fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text.uppercase(), color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
}

@Composable
private fun LabeledValue(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextSecondary, fontSize = 11.sp)
        Text(value, color = TextPrimary, fontSize = 11.sp)
    }
}

@Composable
private fun GoldSlider(
    value: Float, range: ClosedFloatingPointRange<Float>, enabled: Boolean, tag: String,
    onChange: (Float) -> Unit, onFinished: () -> Unit = {}
) {
    Slider(
        value = value, onValueChange = onChange, onValueChangeFinished = onFinished,
        valueRange = range, enabled = enabled,
        modifier = Modifier.testTag(tag),
        colors = SliderDefaults.colors(
            thumbColor = ChampagneGold, activeTrackColor = ChampagneGold, inactiveTrackColor = CharcoalBorder
        )
    )
}

@Composable
private fun CropRow(label: String, value: Float, enabled: Boolean, tag: String, onChange: (Float) -> Unit) {
    Column {
        LabeledValue(label, "${(value * 100).toInt()}%")
        GoldSlider(value, 0f..0.9f, enabled, tag, onChange)
    }
}

@Composable
private fun QuickAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    enabled: Boolean,
    modifier: Modifier,
    tag: String,
    onClick: () -> Unit,
    active: Boolean = false
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) ChampagneGold else CharcoalBorder),
        modifier = modifier.heightIn(min = 52.dp).testTag(tag)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = if (active) ChampagneGoldLight else TextPrimary, modifier = Modifier.size(18.dp))
            Text(
                label, fontSize = 9.sp, color = if (active) ChampagneGoldLight else TextSecondary,
                maxLines = 1, textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
private fun ChoiceChip(label: String, chosen: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        color = if (chosen) CharcoalSurface else Color.Transparent,
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (chosen) ChampagneGold else CharcoalBorder),
        modifier = modifier.heightIn(min = 44.dp).clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(label, color = if (chosen) TextPrimary else TextSecondary, fontSize = 11.sp)
        }
    }
}
